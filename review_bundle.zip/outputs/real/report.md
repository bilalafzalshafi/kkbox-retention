# Can listening behavior warn us before subscribers leave?

KKBOX · OBSERVATIONAL BACKTEST

A monthly churn prediction task with snapshot eligibility frozen from past billing state and outcomes built from cancellation-adjusted renewal gaps. Results describe the audited customer sample and observed periods; intervention effects require randomization.

Implemented outcome: Eligibility uses the scheduled expiry from the latest officially ordered pre-snapshot transaction. Outcomes then look forward: cancellations can shorten that expiry before the first later non-cancellation transaction, and renewal requires the resulting gap to be less than 30 days. A gap of 30 days or more is churn.

The implementation completed SQL snapshot construction, complete-cohort temporal training, four billing/listening model comparisons, calibration, monthly top-decile capture, and a subscriber-cluster bootstrap of incremental log loss. Data mode: real. No randomized retention effect has been measured.

The validation-selected candidate is Listening XGBoost; the final test months were not used to select it. The default real-data configuration samples one out of every 100 subscribers by hash and retains all records for each sampled subscriber. Source file sizes, optional hashes and the exact config are in provenance.json.

                model     n  churners  log_loss    brier  recall_at_10  selected  captured
      Billing XGBoost 17286       754  0.127018 0.033239      0.645889      1730       487
     Billing logistic 17286       754  0.129602 0.034432      0.657825      1730       496
Historical prevalence 17286       754  0.182266 0.042027      0.122016      1730        92
    Listening XGBoost 17286       754  0.119060 0.030604      0.712202      1730       537
   Listening logistic 17286       754  0.122001 0.031875      0.710875      1730       536

Incremental behavioral value (negative log-loss difference favors listening):

                               comparison  delta_log_loss    ci_low   ci_high  subscribers  snapshots  bootstrap_reps                                                                                                interpretation
Listening logistic minus Billing logistic       -0.007601 -0.009301 -0.005841         9520      17286             500 Negative favors listening; subscriber-cluster interval conditional on fitted predictions and observed months.
  Listening XGBoost minus Billing XGBoost       -0.007958 -0.009593 -0.006295         9520      17286             500 Negative favors listening; subscriber-cluster interval conditional on fitted predictions and observed months.

These intervals describe the observed test months conditional on fixed fitted models. Repeated users are resampled as clusters. The result is not a causal effect of listening, and the bootstrap does not quantify future month drift.

All outcome rates use labeled subscriber snapshots as their denominator; cohort tables additionally report eligible, censored, renewal and churn counts. The late March cohort is scored, but its incomplete follow-up is not treated as observed churn. See docs/analysis_plan.md for the snapshot eligibility freeze, cancellation-adjusted outcome definition and timing boundaries.

Interpret findings for this sampled and filtered population; inspect exclusion rates before generalizing.
